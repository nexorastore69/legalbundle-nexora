(() => {
  const config = window.NEXORA_CONFIG || {};
  const checkoutModal = document.getElementById('checkoutModal');
  const policyModal = document.getElementById('policyModal');
  const form = document.getElementById('checkoutForm');
  const gatewayNote = document.getElementById('gatewayNote');
  document.getElementById('year').textContent = new Date().getFullYear();

  // Hero carousel: autoplay, arrows, dots, keyboard support and pause-on-hover.
  const heroCarousel = document.querySelector('.hero-carousel');
  if (heroCarousel) {
    const track = heroCarousel.querySelector('.hero-carousel-track');
    const slides = [...heroCarousel.querySelectorAll('.hero-carousel-slide')];
    const dots = [...heroCarousel.querySelectorAll('.hero-carousel-dots button')];
    const prev = heroCarousel.querySelector('.hero-carousel-arrow.prev');
    const next = heroCarousel.querySelector('.hero-carousel-arrow.next');
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let activeIndex = 0;
    let autoplayId;
    const showSlide = index => {
      activeIndex = (index + slides.length) % slides.length;
      track.style.transform = `translateX(-${activeIndex * 100}%)`;
      slides.forEach((slide, i) => slide.setAttribute('aria-hidden', String(i !== activeIndex)));
      dots.forEach((dot, i) => {
        dot.classList.toggle('is-active', i === activeIndex);
        dot.setAttribute('aria-pressed', String(i === activeIndex));
      });
    };
    const stopAutoplay = () => { if (autoplayId) window.clearInterval(autoplayId); autoplayId = null; };
    const startAutoplay = () => {
      stopAutoplay();
      if (!reducedMotion && !document.hidden) autoplayId = window.setInterval(() => showSlide(activeIndex + 1), 5000);
    };
    prev.addEventListener('click', () => { showSlide(activeIndex - 1); startAutoplay(); });
    next.addEventListener('click', () => { showSlide(activeIndex + 1); startAutoplay(); });
    dots.forEach((dot, i) => dot.addEventListener('click', () => { showSlide(i); startAutoplay(); }));
    heroCarousel.addEventListener('mouseenter', stopAutoplay);
    heroCarousel.addEventListener('mouseleave', startAutoplay);
    heroCarousel.addEventListener('focusin', stopAutoplay);
    heroCarousel.addEventListener('focusout', startAutoplay);
    document.addEventListener('visibilitychange', () => document.hidden ? stopAutoplay() : startAutoplay());
    showSlide(0);
    startAutoplay();
  }

  const openModal = modal => { modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; };
  const closeModal = modal => { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); document.body.style.overflow=''; };
  document.querySelectorAll('.checkout-open').forEach(btn => btn.addEventListener('click', () => { window.location.href = (config.CHECKOUT_URL || '').trim(); }));
  document.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', () => { closeModal(checkoutModal); closeModal(policyModal); }));
  document.addEventListener('keydown', e => { if(e.key === 'Escape'){ closeModal(checkoutModal); closeModal(policyModal); } });

  const policyCopy = {
    privacy: `<h3>Information collected</h3><p>When checkout is enabled, NEXORA may collect the name, email address and phone number you submit to process your order, provide product access and respond to support requests. Payment details should be processed by the selected payment gateway; do not store card or UPI credentials on this website.</p><h3>Use of information</h3><p>Order details may be used for digital delivery, customer support, order records and service-related communication. If analytics or advertising pixels are enabled, disclose the relevant data collection and obtain consent where required.</p><h3>Contact</h3><p>Replace the support contact in the site configuration before launch. Do not publish this policy until your actual data practices have been reviewed.</p>`,
    terms: `<h3>Digital product</h3><p>The product is a digital collection of legal drafting reference resources. No physical shipment is included.</p><h3>Permitted use</h3><p>Purchase grants the buyer the personal or professional-use licence described at checkout. Resale, redistribution, public sharing or sublicensing of the files is prohibited unless expressly authorized in writing.</p><h3>Delivery</h3><p>Digital access is provided after payment confirmation through the delivery channel configured by NEXORA.</p><h3>Governing law</h3><p>Terms should be reviewed and completed with the correct business identity, address, jurisdiction and applicable Indian consumer-law requirements before launch.</p>`,
    disclaimer: `<h3>Not legal advice</h3><p>Legal drafts and templates are privately compiled reference and drafting-assistance resources. They do not constitute legal advice and do not create an attorney-client relationship.</p><h3>Independent verification</h3><p>Users are responsible for checking facts, current statutes, amendments, case law, procedural requirements and local court rules before adapting or filing any document.</p><h3>No government affiliation</h3><p>NEXORA is not affiliated with any court, bar council or government department. No particular legal outcome is promised or guaranteed.</p>`,
    refund: `<h3>Digital product refund terms</h3><p>Clearly disclose the refund, cancellation and access policy before payment. Any no-refund provision must be reviewed for compliance with applicable Indian law and the payment provider's rules. Do not rely on a blanket statement to remove statutory consumer rights.</p><h3>Access issues</h3><p>Provide a working support email or phone number and a reasonable process for resolving failed delivery, broken links or duplicate payments. Add your real support contact before launch.</p>`
  };
  document.querySelectorAll('[data-policy]').forEach(link => link.addEventListener('click', e => {
    e.preventDefault(); const key = link.dataset.policy;
    document.getElementById('policyTitle').textContent = ({privacy:'Privacy Policy',terms:'Terms & Conditions',disclaimer:'Disclaimer',refund:'Refund Policy'})[key] || 'Policy';
    document.getElementById('policyContent').innerHTML = policyCopy[key] || '';
    openModal(policyModal);
  }));

  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!form.reportValidity()) return;
    const checkoutUrl = (config.CHECKOUT_URL || '').trim();
    if (checkoutUrl) {
      // Redirect directly to the hosted Cosmofeed checkout; do not append personal details to the URL.
      window.location.href = checkoutUrl;
    } else {
      gatewayNote.textContent = 'Demo mode: no payment has been taken. Add your hosted checkout URL in config.js and connect verified digital delivery before publishing.';
      gatewayNote.style.color = '#b56a25';
    }
  });

  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.desktop-nav');
  menu.addEventListener('click', () => { const shown = nav.classList.toggle('show'); menu.setAttribute('aria-expanded', String(shown)); menu.textContent = shown ? '×' : '☰'; });
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { nav.classList.remove('show'); menu.setAttribute('aria-expanded','false'); menu.textContent='☰'; }));

  // 15-minute per-session display countdown. This is a UI timer only; configure a
  // real server-side campaign deadline before claiming that an offer expires.
  const timerKey = 'nexora_offer_session_deadline_v1';
  const timerMinutes = document.getElementById('timer-minutes');
  const timerSeconds = document.getElementById('timer-seconds');
  const urgencyBand = document.querySelector('.urgency-band');
  if (timerMinutes && timerSeconds) {
    let deadline = Number(sessionStorage.getItem(timerKey));
    if (!deadline || !Number.isFinite(deadline)) {
      deadline = Date.now() + 15 * 60 * 1000;
      sessionStorage.setItem(timerKey, String(deadline));
    }
    let timerInterval = null;
    const tick = () => {
      const remaining = Math.max(0, deadline - Date.now());
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      timerMinutes.textContent = String(mins).padStart(2, '0');
      timerSeconds.textContent = String(secs).padStart(2, '0');
      if (remaining <= 0) {
        if (urgencyBand) {
          const small = urgencyBand.querySelector('.urgency-copy small');
          if (small) small.textContent = 'Session timer ended · confirm current offer before checkout';
          urgencyBand.classList.add('timer-ended');
        }
        clearInterval(timerInterval);
      }
    };
    tick();
    timerInterval = setInterval(tick, 1000);
  }

  // Activity toast: show verified purchase data only when a real order-feed URL
  // is configured. Otherwise rotate factual product details, never invented buyers.
  const toast = document.getElementById('activityToast');
  const toastTitle = document.getElementById('toastTitle');
  const toastText = document.getElementById('toastText');
  const toastClose = document.getElementById('toastClose');
  const toastFacts = [
    ['Inside the NEXORA bundle', '10,000+ legal drafts across multiple fields.'],
    ['Four draft languages', 'Hindi, English, Gujarati and Marathi resources.'],
    ['Editable document formats', 'The collection includes editable MS Word templates.'],
    ['One-time digital purchase', 'The advertised launch price is ₹149.'],
    ['Six-language dictionary', 'A multilingual legal vocabulary reference is included.']
  ];
  let toastTimer;
  const hideToast = () => { if (toast) toast.classList.remove('show'); };
  if (toastClose) toastClose.addEventListener('click', hideToast);
  async function showActivityToast() {
    if (!toast || !toastTitle || !toastText) return;
    const endpoint = (config.RECENT_PURCHASES_ENDPOINT || '').trim();
    let shownPurchase = false;
    if (endpoint) {
      try {
        const response = await fetch(endpoint, { headers: { 'Accept': 'application/json' }, cache: 'no-store' });
        if (!response.ok) throw new Error('Purchase feed unavailable');
        const orders = await response.json();
        if (Array.isArray(orders) && orders.length) {
          const valid = orders.filter(order => order && typeof order.firstName === 'string' && order.firstName.trim());
          if (valid.length) {
            const order = valid[Math.floor(Math.random() * valid.length)];
            toastTitle.textContent = `${order.firstName.trim()}${order.city ? ` from ${String(order.city).trim()}` : ''} purchased`;
            toastText.textContent = order.product ? String(order.product) : 'NEXORA Ultimate Legal Drafts Bundle';
            shownPurchase = true;
          }
        }
      } catch (error) {
        console.warn('NEXORA verified purchase feed could not be loaded.', error);
      }
    }
    if (!shownPurchase) {
      const fact = toastFacts[Math.floor(Math.random() * toastFacts.length)];
      toastTitle.textContent = fact[0];
      toastText.textContent = fact[1];
    }
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(hideToast, 9000);
  }
  // First reminder after two minutes, then every two minutes thereafter.
  setInterval(showActivityToast, 120000);

})();
