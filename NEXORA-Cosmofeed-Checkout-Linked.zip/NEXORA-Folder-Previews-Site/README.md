# NEXORA — Ultimate Legal Drafts Mega Bundle

A responsive static sales landing page for the NEXORA digital legal-drafts bundle.

## Included
- NEXORA's supplied logo in the header and footer.
- Hero sequence: headline → product artwork → short details → CTA.
- Blue, white and black theme with highlighted card borders.
- 15-minute per-session countdown display.
- Comparison table recreated from the supplied reference image; the bundle offer is shown as ₹149.
- Eight English/Hinglish illustrative review cards in an animated marquee. They are explicitly marked as sample copy, not real testimonials.
- A notification toast every two minutes. It displays product facts by default; it only displays purchaser names if a real verified purchase feed is configured.
- Responsive layout, checkout modal, FAQ, policy dialogs and mobile purchase bar.

## Preview locally
Open `index.html` in a browser. Keep `styles.css`, `script.js`, `config.js` and the `assets` folder alongside it.

## Configure checkout
Edit `config.js`:

```js
window.NEXORA_CONFIG = {
  CHECKOUT_URL: "https://your-hosted-checkout-url.example",
  SUPPORT_EMAIL: "support@example.com",
  SUPPORT_WHATSAPP: "+91XXXXXXXXXX",
  PRICE_INR: 149,
  ORIGINAL_PRICE_INR: 1499,
  RECENT_PURCHASES_ENDPOINT: ""
};
```

The checkout form currently performs a front-end handoff to a hosted checkout URL. For production, create orders server-side, verify payment signatures/webhooks server-side, and release download access only after verified payment. Never put gateway secret keys in browser code.

## Verified purchase notifications
The site intentionally does not invent purchaser names or claim that a person bought the product. If you have a backend endpoint containing verified recent orders, set `RECENT_PURCHASES_ENDPOINT` to that endpoint. It should return JSON like:

```json
[
  {"firstName":"Asha","city":"Mumbai","product":"Ultimate Legal Drafts Bundle","purchasedAt":"2026-11-15T10:30:00+05:30"}
]
```

Only include real, consented order data. If no endpoint is configured or it fails, the two-minute toast rotates factual bundle information instead.

## Countdown note
The 15-minute countdown is a per-browser-session display timer. It is not a server-enforced offer expiry. Before advertising a real deadline, configure a genuine campaign end time and enforce it server-side at checkout. The countdown does not block checkout or change the ₹149 price.

## Review note
The eight animated English/Hinglish review cards are clearly labeled illustrative sample copy, not actual customer testimonials. Replace them with genuine customer reviews and permission before publishing them as testimonials.

## Deploy to Netlify
1. Extract the ZIP.
2. Open Netlify and choose **Add new site → Deploy manually**.
3. Drag the extracted `nexora-legal-drafts-site` folder into the deploy area.
4. Add your custom domain in Site configuration when ready.

## Deploy to Vercel
1. Upload the folder to a GitHub repository.
2. Import the repository into Vercel.
3. Choose **Other** as the framework preset; leave build command empty and set output directory to `.`.
4. Deploy.

## Before launch
- Connect and test a real payment gateway and server-side payment verification.
- Configure automated digital delivery and verify the download link.
- Replace placeholder support contacts and complete policies.
- Replace sample review cards with genuine feedback.
- Confirm competitor price ranges and comparison claims before publishing.
- Confirm product-count, language, access-duration and included-resource claims against the actual bundle.
- Add consent-aware analytics and Meta Pixel configuration if required.

## Product disclaimer
Legal drafts and templates are reference/drafting-assistance resources only, not legal advice. Buyers must verify facts, current laws, amendments, case law and local court rules before use.


## Hero image carousel
The hero section includes three square campaign images and automatically advances every 5 seconds. Visitors can also use the previous/next arrows or pagination dots. Autoplay pauses on hover/focus and respects reduced-motion preferences.
