/* NEXORA site configuration.
   Set CHECKOUT_URL to your hosted checkout URL after your payment gateway is configured.
   For Razorpay, create/verify orders server-side; never place secret keys in this file.
*/
window.NEXORA_CONFIG = {
  CHECKOUT_URL: "https://cosmofeed.com/vp/6afa080e1e8b150007ce4842",
  SUPPORT_EMAIL: "",
  SUPPORT_WHATSAPP: "",
  PRICE_INR: 149,
  ORIGINAL_PRICE_INR: 1499,
  // Optional: URL returning verified recent purchases as [{firstName, city, product, purchasedAt}].
  // Leave blank until a real order feed is available; the site will show product facts instead.
  RECENT_PURCHASES_ENDPOINT: ""
};
